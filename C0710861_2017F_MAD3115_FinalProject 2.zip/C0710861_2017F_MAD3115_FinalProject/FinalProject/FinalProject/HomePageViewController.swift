//
//  HomePageViewController.swift
//  c0710861
//
//  Created by MacStudent on 2017-10-24.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class HomePageViewController: UIViewController {
    
    
    @IBOutlet weak var btnStartQuiz: UIButton!
    @IBOutlet weak var btnScores: UIButton!
    @IBOutlet weak var btnInstructions: UIButton!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        btnStartQuiz.layer.cornerRadius = 7
        btnScores.layer.cornerRadius = 7
        btnInstructions.layer.cornerRadius = 7
        //btnLogOut.layer.cornerRadius = 7
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
