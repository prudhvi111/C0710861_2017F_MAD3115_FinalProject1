//
//  Questions.swift
//  FinalProject
//
//  Created by MacStudent on 2017-10-24.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation


class Questions{
    
    
   static var arrayQuestions:NSArray!
    
    
    var questionNo : Int!
    var question : String!
    var Option1 : String!
    var Option2 : String!
    var Option3 : String!
    var Option4 : String!
    var Answer : String!
    
    static var QuestionList = [Questions]()
    
    static var Answers = [String]()
    
    static var TrueAnswer = [Int]()
    
    static var Right_Answers = 0
    static var Wrong_Answers = 0
    
    
    
    init() {
        
        self.questionNo = 0
        self.question = ""
        self.Option1 = ""
        self.Option2 = ""
        self.Option3 = ""
        self.Option4 = ""
        self.Answer = ""
        
    }
    
    
    init(questionNo : Int, question : String, Option1 : String, Option2 : String, Option3 : String, Option4 : String, Answer : String) {
        
        self.questionNo = questionNo
        self.question = question
        self.Option1 = Option1
        self.Option2 = Option2
        self.Option3 = Option3
        self.Option4 = Option4
        self.Answer = Answer
        
    }
    
    static func addQuestion(question : Questions)  {
        
        if QuestionList[question.questionNo] == nil {
            
           QuestionList[question.questionNo] = question
            
        }
        
    }
    
    static func AddAnswers(questionNo : Int, answer: String){
        
        if Answers[questionNo] == nil {
            
            Answers[questionNo] = answer
            
        }
        
    }
    
    static func checkAnswer(){
        
        for i in 1...10 {
            
            if QuestionList[i].Answer == Answers[i]{
                
                Right_Answers += 1
                
            }else{
                
                Wrong_Answers += 1
                
            }
            
        }
        
    }
    
    
    func RandomIndexGeneratorCreator() -> [Int] {
        
        var RandomIndexes = [Int]()
        
        for _ in 0..<10 {
            let randomQuesIndex = (arc4random() % 20);
            RandomIndexes.append(Int(randomQuesIndex))
        }
        
        return RandomIndexes
    }
    
    static func setQuestions(){
        
            var paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true) as Array
            let documentPath = paths[0] as String
            let path = documentPath.appending("/QuestionsPlist")
            
            let fileManager = FileManager.default
            
            if !fileManager.fileExists(atPath: path) {
                if let bundlePath = Bundle.main.path(forResource: "QuestionsPlist", ofType: "plist") {
                    do {
                        try fileManager.copyItem(at: URL(fileURLWithPath: bundlePath), to: URL(fileURLWithPath: path))
                    } catch {
                        print("copy failure")
                    }
                }
                else {
                    print("product plist not found")
                }
            }
            else {
                print("file product plist already exist at path")
            }
        arrayQuestions = NSDictionary(contentsOfFile: path)?.value(forKey: "Questions") as! NSArray

//            print("--------------------------------------------------------------------------------------")
//            print("load productlist.plist is \(arrayQuestions.description)")
//            print("--------------------------------------------------------------------------------------")
        
//        var randomArray = self.RandomIndexGeneratorCreator(<#T##Questions#>)
//        
        for (value) in arrayQuestions {
            
//            print("Key >> \(key)")
            print("Value >> \(value)")
            
        }
        
        print("-------------------------------------------------------------------Ok-------------------")
        print(arrayQuestions[2])
        print("------------------------------------------------------------------------Ok over--------------")
//        for value in arrayQuestions {
//
//            print("Keys \(value)")
//
//        }
//
        
        
        
        
    }
    
    
    
    // Main class
    
}
