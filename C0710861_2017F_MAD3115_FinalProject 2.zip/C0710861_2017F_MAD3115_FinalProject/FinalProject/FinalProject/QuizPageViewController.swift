//
//  QuizPageViewController.swift
//  c0710861
//
//  Created by MacStudent on 2017-10-24.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class QuizPageViewController: UIViewController, UIPickerViewDelegate {
   
    var Options = [String] ()
    
    

    
    @IBOutlet weak var mySlider: UISlider!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        
        
        Options = ["Option1", "Option2", "Option3", "Option4"]
        
        
        var Questionsdictionary = [
            
            1 : [
                
                "Question1" : "Which resistive component is designed to be temperature sensitive?",
                "Option1" : "thermistor",
                "Option2" : "rheostat",
                "Option3" : "potentiometer",
                "Option4" : "photoconductive cell",
                "Answer" : "option1"
            ],
            
            2 : [
                
                "Question1" : "A voltage will influence current only if the circuit is",
                "Option1" : "open",
                "Option2" : "insulated",
                "Option3" : "high resistance",
                "Option4" : "closed",
                "Answer" : "option4"
            ],
            
            3 : [
            
            "Question" : "An atom's atomic number is determined by the number of",
            "Option1" : "neutrons minus protons",
            "Option2" : "protons",
            "Option3" : "electrons",
            "Option4" : "neutrons",
            "Answer" : "option2"
            ],

            4 : [
                
                "Question" : "In practical applications, battery voltage: ",
                "Option1" : " is restored as soon as disconnect occur ",
                "Option2" : "is lowered as the load increases",
                "Option3" : "may be stored indefinitely",
                "Option4" : "will be reduced to zero as power is drawn",
                "Answer" : "option2"
            ],
            5 : [
            
                "Question" : "Primary batteries, unlike secondary batteries, may be:  ",
            "Option1" : " electron and element ",
            "Option2" : "used once ",
            "Option3" : "recharged over and over",
            "Option4" : "stored indefinitely",
            "Answer" : "opion1"
            ],
            6 : [
            
                "Question" : "The negative and positive charge symbols are assigned (in that order) to the",
            "Option1" : "proton and electron  ",
            "Option2" : "electron and proton ",
            "Option3" : "atom and nucleus",
            "Option4" : "electron and element",
            "Answer" : "option2"
            ],
            7 : [
            
            "Question" : " A voltmeter is used:  ",
            "Option1" : " to measure current ",
            "Option2" : "in series with the circuit ",
            "Option3" : "in parallel with the circuit",
            "Option4" : "to measure coulombs",
            "Answer" : "option3"
            ],
            8 : [
            
            "Question" : " What are the unit and symbol for current?  ",
            "Option1" : "A  ",
            "Option2" : " I",
            "Option3" : "Q",
            "Option4" : "I",
            "Answer" : "option4"
            ],
            9 : [
            
                "Question" : "Which part of an atom has no electrical charge? ",
            "Option1" : "electron  ",
            "Option2" : "neutron ",
            "Option3" : "proton",
            "Option4" : "all of the above",
            "Answer" : "option2"
            ],
            
            10 : [
            
            "Question" : "Which voltage source converts chemical energy to electrical energy?   ",
            "Option1" : "Electrical generator  ",
            "Option2" : "Battery ",
            "Option3" : "Solar cell",
            "Option4" : "Electronic power supply",
            "Answer" : "option2"
            ],
            
            
            
        ]
        
        // access dictionary )))))
        var dictQuestion : [String : String] = Questionsdictionary[1]!
        print(Questionsdictionary.description)
        print(dictQuestion.description)
     //   print(dictQuestion["Ans"]!)
        
        
        Questions.setQuestions()
//        print(Questions.setQuestions())
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
//    func numberOfComponents(in pickerView: UIPickerView) -> Int {
//        return 1
//    }
//
//    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
//        return Options.count
//    }
//
//    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
//        return Options[row]
//    }
//    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
//        print(Options[Optionselector.selectedRow(inComponent: 0)])
//    }
    
    
    
    

}
